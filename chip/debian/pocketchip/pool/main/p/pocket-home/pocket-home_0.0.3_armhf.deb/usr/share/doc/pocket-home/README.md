# PocketCHIP Launcher

### Required Packages

```sh
sudo apt-get install \
    git \
    build-essential \
    libx11-dev \
    libxrandr-dev \
    libxcursor-dev \
    libxft-dev \
    libxinerama-dev \
    libnm-glib-dev \
    network-manager-dev
```
