axp209_write_address 0x82 0x83
echo "ADC was reset to the factory default value."
